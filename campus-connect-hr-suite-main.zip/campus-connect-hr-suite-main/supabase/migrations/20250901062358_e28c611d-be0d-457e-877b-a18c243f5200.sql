-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.positions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.recruitment_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.job_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.leave_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_enrollments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.grades ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fee_structures ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_fees ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fee_payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.research_grants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.timetables ENABLE ROW LEVEL SECURITY;

-- Create security definer functions to avoid infinite recursion
CREATE OR REPLACE FUNCTION public.get_user_role(user_uuid UUID)
RETURNS app_role
LANGUAGE SQL
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT role FROM public.user_roles WHERE user_id = user_uuid LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.has_role(user_uuid UUID, role_name app_role)
RETURNS BOOLEAN
LANGUAGE SQL
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = user_uuid AND role = role_name
  );
$$;

CREATE OR REPLACE FUNCTION public.is_admin(user_uuid UUID)
RETURNS BOOLEAN
LANGUAGE SQL
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT public.has_role(user_uuid, 'admin');
$$;

CREATE OR REPLACE FUNCTION public.is_hr_staff(user_uuid UUID)
RETURNS BOOLEAN
LANGUAGE SQL
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT public.has_role(user_uuid, 'hr_staff');
$$;

CREATE OR REPLACE FUNCTION public.is_faculty(user_uuid UUID)
RETURNS BOOLEAN
LANGUAGE SQL
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT public.has_role(user_uuid, 'faculty');
$$;

CREATE OR REPLACE FUNCTION public.is_student(user_uuid UUID)
RETURNS BOOLEAN
LANGUAGE SQL
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT public.has_role(user_uuid, 'student');
$$;

-- Fix the search path for the existing function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Profiles policies
CREATE POLICY "Users can view their own profile" ON public.profiles
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can update their own profile" ON public.profiles
  FOR UPDATE USING (user_id = auth.uid());

CREATE POLICY "Admin and HR can view all profiles" ON public.profiles
  FOR SELECT USING (
    public.is_admin(auth.uid()) OR 
    public.is_hr_staff(auth.uid())
  );

CREATE POLICY "Admin and HR can update all profiles" ON public.profiles
  FOR UPDATE USING (
    public.is_admin(auth.uid()) OR 
    public.is_hr_staff(auth.uid())
  );

CREATE POLICY "Admin and HR can create profiles" ON public.profiles
  FOR INSERT WITH CHECK (
    public.is_admin(auth.uid()) OR 
    public.is_hr_staff(auth.uid())
  );

-- User roles policies
CREATE POLICY "Users can view their own roles" ON public.user_roles
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Admin can manage all user roles" ON public.user_roles
  FOR ALL USING (public.is_admin(auth.uid()));

-- Departments policies
CREATE POLICY "Everyone can view departments" ON public.departments
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admin and HR can manage departments" ON public.departments
  FOR ALL USING (
    public.is_admin(auth.uid()) OR 
    public.is_hr_staff(auth.uid())
  );

-- Positions policies
CREATE POLICY "Everyone can view positions" ON public.positions
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admin and HR can manage positions" ON public.positions
  FOR ALL USING (
    public.is_admin(auth.uid()) OR 
    public.is_hr_staff(auth.uid())
  );

-- Employees policies
CREATE POLICY "Users can view their own employee record" ON public.employees
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Admin and HR can view all employees" ON public.employees
  FOR SELECT USING (
    public.is_admin(auth.uid()) OR 
    public.is_hr_staff(auth.uid())
  );

CREATE POLICY "Admin and HR can manage employees" ON public.employees
  FOR ALL USING (
    public.is_admin(auth.uid()) OR 
    public.is_hr_staff(auth.uid())
  );

-- Recruitment jobs policies
CREATE POLICY "Everyone can view active jobs" ON public.recruitment_jobs
  FOR SELECT TO authenticated USING (is_active = true);

CREATE POLICY "Admin and HR can manage jobs" ON public.recruitment_jobs
  FOR ALL USING (
    public.is_admin(auth.uid()) OR 
    public.is_hr_staff(auth.uid())
  );

-- Job applications policies
CREATE POLICY "Admin and HR can view applications" ON public.job_applications
  FOR SELECT USING (
    public.is_admin(auth.uid()) OR 
    public.is_hr_staff(auth.uid())
  );

CREATE POLICY "Anyone can submit applications" ON public.job_applications
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Admin and HR can manage applications" ON public.job_applications
  FOR UPDATE USING (
    public.is_admin(auth.uid()) OR 
    public.is_hr_staff(auth.uid())
  );

-- Leave requests policies
CREATE POLICY "Users can view their own leave requests" ON public.leave_requests
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can create their own leave requests" ON public.leave_requests
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admin and HR can view all leave requests" ON public.leave_requests
  FOR SELECT USING (
    public.is_admin(auth.uid()) OR 
    public.is_hr_staff(auth.uid())
  );

CREATE POLICY "Admin and HR can manage leave requests" ON public.leave_requests
  FOR UPDATE USING (
    public.is_admin(auth.uid()) OR 
    public.is_hr_staff(auth.uid())
  );

-- Attendance records policies
CREATE POLICY "Users can view their own attendance" ON public.attendance_records
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can create their own attendance" ON public.attendance_records
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admin, HR and Faculty can view all attendance" ON public.attendance_records
  FOR SELECT USING (
    public.is_admin(auth.uid()) OR 
    public.is_hr_staff(auth.uid()) OR
    public.is_faculty(auth.uid())
  );

CREATE POLICY "Admin and HR can manage attendance" ON public.attendance_records
  FOR ALL USING (
    public.is_admin(auth.uid()) OR 
    public.is_hr_staff(auth.uid())
  );

-- Courses policies
CREATE POLICY "Everyone can view courses" ON public.courses
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admin and Faculty can manage courses" ON public.courses
  FOR ALL USING (
    public.is_admin(auth.uid()) OR 
    public.is_faculty(auth.uid())
  );

-- Classes policies
CREATE POLICY "Everyone can view classes" ON public.classes
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Faculty can view their own classes" ON public.classes
  FOR SELECT USING (faculty_id = auth.uid());

CREATE POLICY "Faculty can manage their own classes" ON public.classes
  FOR ALL USING (faculty_id = auth.uid());

CREATE POLICY "Admin can manage all classes" ON public.classes
  FOR ALL USING (public.is_admin(auth.uid()));

-- Students policies
CREATE POLICY "Users can view their own student record" ON public.students
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Admin, HR and Faculty can view students" ON public.students
  FOR SELECT USING (
    public.is_admin(auth.uid()) OR 
    public.is_hr_staff(auth.uid()) OR
    public.is_faculty(auth.uid())
  );

CREATE POLICY "Admin and HR can manage students" ON public.students
  FOR ALL USING (
    public.is_admin(auth.uid()) OR 
    public.is_hr_staff(auth.uid())
  );

-- Student enrollments policies
CREATE POLICY "Students can view their own enrollments" ON public.student_enrollments
  FOR SELECT USING (
    student_id IN (
      SELECT id FROM public.students WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Faculty can view enrollments for their classes" ON public.student_enrollments
  FOR SELECT USING (
    class_id IN (
      SELECT id FROM public.classes WHERE faculty_id = auth.uid()
    )
  );

CREATE POLICY "Admin and HR can view all enrollments" ON public.student_enrollments
  FOR SELECT USING (
    public.is_admin(auth.uid()) OR 
    public.is_hr_staff(auth.uid())
  );

CREATE POLICY "Admin can manage enrollments" ON public.student_enrollments
  FOR ALL USING (public.is_admin(auth.uid()));

-- Grades policies
CREATE POLICY "Students can view their own grades" ON public.grades
  FOR SELECT USING (
    student_id IN (
      SELECT id FROM public.students WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Faculty can view grades for their classes" ON public.grades
  FOR SELECT USING (
    class_id IN (
      SELECT id FROM public.classes WHERE faculty_id = auth.uid()
    )
  );

CREATE POLICY "Faculty can manage grades for their classes" ON public.grades
  FOR ALL USING (
    class_id IN (
      SELECT id FROM public.classes WHERE faculty_id = auth.uid()
    )
  );

CREATE POLICY "Admin can view all grades" ON public.grades
  FOR SELECT USING (public.is_admin(auth.uid()));

-- Fee structures policies
CREATE POLICY "Everyone can view fee structures" ON public.fee_structures
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admin can manage fee structures" ON public.fee_structures
  FOR ALL USING (public.is_admin(auth.uid()));

-- Student fees policies
CREATE POLICY "Students can view their own fees" ON public.student_fees
  FOR SELECT USING (
    student_id IN (
      SELECT id FROM public.students WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Admin can view all student fees" ON public.student_fees
  FOR SELECT USING (public.is_admin(auth.uid()));

CREATE POLICY "Admin can manage student fees" ON public.student_fees
  FOR ALL USING (public.is_admin(auth.uid()));

-- Fee payments policies
CREATE POLICY "Students can view their own payments" ON public.fee_payments
  FOR SELECT USING (
    student_fee_id IN (
      SELECT sf.id FROM public.student_fees sf
      JOIN public.students s ON sf.student_id = s.id
      WHERE s.user_id = auth.uid()
    )
  );

CREATE POLICY "Students can create their own payments" ON public.fee_payments
  FOR INSERT WITH CHECK (
    student_fee_id IN (
      SELECT sf.id FROM public.student_fees sf
      JOIN public.students s ON sf.student_id = s.id
      WHERE s.user_id = auth.uid()
    )
  );

CREATE POLICY "Admin can view all payments" ON public.fee_payments
  FOR SELECT USING (public.is_admin(auth.uid()));

CREATE POLICY "Admin can manage payments" ON public.fee_payments
  FOR ALL USING (public.is_admin(auth.uid()));

-- Research grants policies
CREATE POLICY "Users can view their own grants" ON public.research_grants
  FOR SELECT USING (
    principal_investigator = auth.uid() OR 
    auth.uid() = ANY(co_investigators)
  );

CREATE POLICY "Faculty can create grants" ON public.research_grants
  FOR INSERT WITH CHECK (
    public.is_faculty(auth.uid()) AND 
    principal_investigator = auth.uid()
  );

CREATE POLICY "Users can update their own grants" ON public.research_grants
  FOR UPDATE USING (principal_investigator = auth.uid());

CREATE POLICY "Admin can view all grants" ON public.research_grants
  FOR SELECT USING (public.is_admin(auth.uid()));

CREATE POLICY "Admin can manage all grants" ON public.research_grants
  FOR ALL USING (public.is_admin(auth.uid()));

-- Events policies
CREATE POLICY "Everyone can view public events" ON public.events
  FOR SELECT TO authenticated USING (is_public = true);

CREATE POLICY "Department members can view department events" ON public.events
  FOR SELECT USING (
    department_id IN (
      SELECT e.department_id FROM public.employees e 
      WHERE e.user_id = auth.uid()
    )
  );

CREATE POLICY "Event organizers can manage their events" ON public.events
  FOR ALL USING (organized_by = auth.uid());

CREATE POLICY "Admin can manage all events" ON public.events
  FOR ALL USING (public.is_admin(auth.uid()));

-- Documents policies
CREATE POLICY "Everyone can view public documents" ON public.documents
  FOR SELECT TO authenticated USING (is_public = true);

CREATE POLICY "Users can view their own documents" ON public.documents
  FOR SELECT USING (uploaded_by = auth.uid());

CREATE POLICY "Department members can view department documents" ON public.documents
  FOR SELECT USING (
    department_id IN (
      SELECT e.department_id FROM public.employees e 
      WHERE e.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can upload documents" ON public.documents
  FOR INSERT WITH CHECK (uploaded_by = auth.uid());

CREATE POLICY "Users can update their own documents" ON public.documents
  FOR UPDATE USING (uploaded_by = auth.uid());

CREATE POLICY "Admin can manage all documents" ON public.documents
  FOR ALL USING (public.is_admin(auth.uid()));

-- Notifications policies
CREATE POLICY "Users can view their own notifications" ON public.notifications
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can update their own notifications" ON public.notifications
  FOR UPDATE USING (user_id = auth.uid());

CREATE POLICY "Admin can create notifications for users" ON public.notifications
  FOR INSERT WITH CHECK (public.is_admin(auth.uid()));

-- Timetables policies
CREATE POLICY "Everyone can view timetables" ON public.timetables
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Faculty can manage timetables for their classes" ON public.timetables
  FOR ALL USING (
    class_id IN (
      SELECT id FROM public.classes WHERE faculty_id = auth.uid()
    )
  );

CREATE POLICY "Admin can manage all timetables" ON public.timetables
  FOR ALL USING (public.is_admin(auth.uid()));