export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.4"
  }
  public: {
    Tables: {
      attendance_records: {
        Row: {
          check_in: string | null
          check_out: string | null
          created_at: string
          date: string
          id: string
          location: string | null
          notes: string | null
          status: Database["public"]["Enums"]["attendance_status"]
          updated_at: string
          user_id: string
        }
        Insert: {
          check_in?: string | null
          check_out?: string | null
          created_at?: string
          date: string
          id?: string
          location?: string | null
          notes?: string | null
          status?: Database["public"]["Enums"]["attendance_status"]
          updated_at?: string
          user_id: string
        }
        Update: {
          check_in?: string | null
          check_out?: string | null
          created_at?: string
          date?: string
          id?: string
          location?: string | null
          notes?: string | null
          status?: Database["public"]["Enums"]["attendance_status"]
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      classes: {
        Row: {
          academic_year: string
          course_id: string
          created_at: string
          faculty_id: string
          id: string
          max_students: number | null
          schedule: Json | null
          section: string | null
          semester: string
          updated_at: string
        }
        Insert: {
          academic_year: string
          course_id: string
          created_at?: string
          faculty_id: string
          id?: string
          max_students?: number | null
          schedule?: Json | null
          section?: string | null
          semester: string
          updated_at?: string
        }
        Update: {
          academic_year?: string
          course_id?: string
          created_at?: string
          faculty_id?: string
          id?: string
          max_students?: number | null
          schedule?: Json | null
          section?: string | null
          semester?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "classes_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
        ]
      }
      courses: {
        Row: {
          course_code: string
          course_name: string
          created_at: string
          credits: number
          department_id: string
          description: string | null
          id: string
          is_active: boolean
          prerequisites: string[] | null
          updated_at: string
        }
        Insert: {
          course_code: string
          course_name: string
          created_at?: string
          credits?: number
          department_id: string
          description?: string | null
          id?: string
          is_active?: boolean
          prerequisites?: string[] | null
          updated_at?: string
        }
        Update: {
          course_code?: string
          course_name?: string
          created_at?: string
          credits?: number
          department_id?: string
          description?: string | null
          id?: string
          is_active?: boolean
          prerequisites?: string[] | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "courses_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      departments: {
        Row: {
          code: string
          created_at: string
          description: string | null
          head_user_id: string | null
          id: string
          name: string
          updated_at: string
        }
        Insert: {
          code: string
          created_at?: string
          description?: string | null
          head_user_id?: string | null
          id?: string
          name: string
          updated_at?: string
        }
        Update: {
          code?: string
          created_at?: string
          description?: string | null
          head_user_id?: string | null
          id?: string
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      documents: {
        Row: {
          category: string | null
          created_at: string
          department_id: string | null
          description: string | null
          file_name: string
          file_path: string
          file_size: number
          id: string
          is_public: boolean
          mime_type: string
          parent_document_id: string | null
          tags: string[] | null
          title: string
          updated_at: string
          uploaded_by: string
          version: number
        }
        Insert: {
          category?: string | null
          created_at?: string
          department_id?: string | null
          description?: string | null
          file_name: string
          file_path: string
          file_size: number
          id?: string
          is_public?: boolean
          mime_type: string
          parent_document_id?: string | null
          tags?: string[] | null
          title: string
          updated_at?: string
          uploaded_by: string
          version?: number
        }
        Update: {
          category?: string | null
          created_at?: string
          department_id?: string | null
          description?: string | null
          file_name?: string
          file_path?: string
          file_size?: number
          id?: string
          is_public?: boolean
          mime_type?: string
          parent_document_id?: string | null
          tags?: string[] | null
          title?: string
          updated_at?: string
          uploaded_by?: string
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "documents_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "documents_parent_document_id_fkey"
            columns: ["parent_document_id"]
            isOneToOne: false
            referencedRelation: "documents"
            referencedColumns: ["id"]
          },
        ]
      }
      employees: {
        Row: {
          certifications: string[] | null
          created_at: string
          department_id: string
          employee_id: string
          employment_type: Database["public"]["Enums"]["employment_type"]
          hire_date: string
          id: string
          is_active: boolean
          position_id: string | null
          qualifications: string[] | null
          salary: number | null
          termination_date: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          certifications?: string[] | null
          created_at?: string
          department_id: string
          employee_id: string
          employment_type: Database["public"]["Enums"]["employment_type"]
          hire_date: string
          id?: string
          is_active?: boolean
          position_id?: string | null
          qualifications?: string[] | null
          salary?: number | null
          termination_date?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          certifications?: string[] | null
          created_at?: string
          department_id?: string
          employee_id?: string
          employment_type?: Database["public"]["Enums"]["employment_type"]
          hire_date?: string
          id?: string
          is_active?: boolean
          position_id?: string | null
          qualifications?: string[] | null
          salary?: number | null
          termination_date?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "employees_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employees_position_id_fkey"
            columns: ["position_id"]
            isOneToOne: false
            referencedRelation: "positions"
            referencedColumns: ["id"]
          },
        ]
      }
      events: {
        Row: {
          created_at: string
          date: string
          department_id: string | null
          description: string | null
          end_time: string
          event_type: string
          honorarium: number | null
          id: string
          is_public: boolean
          max_attendees: number | null
          organized_by: string
          resources_needed: string[] | null
          speaker_bio: string | null
          speaker_contact: Json | null
          speaker_name: string | null
          start_time: string
          title: string
          updated_at: string
          venue: string
        }
        Insert: {
          created_at?: string
          date: string
          department_id?: string | null
          description?: string | null
          end_time: string
          event_type: string
          honorarium?: number | null
          id?: string
          is_public?: boolean
          max_attendees?: number | null
          organized_by: string
          resources_needed?: string[] | null
          speaker_bio?: string | null
          speaker_contact?: Json | null
          speaker_name?: string | null
          start_time: string
          title: string
          updated_at?: string
          venue: string
        }
        Update: {
          created_at?: string
          date?: string
          department_id?: string | null
          description?: string | null
          end_time?: string
          event_type?: string
          honorarium?: number | null
          id?: string
          is_public?: boolean
          max_attendees?: number | null
          organized_by?: string
          resources_needed?: string[] | null
          speaker_bio?: string | null
          speaker_contact?: Json | null
          speaker_name?: string | null
          start_time?: string
          title?: string
          updated_at?: string
          venue?: string
        }
        Relationships: [
          {
            foreignKeyName: "events_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      fee_payments: {
        Row: {
          amount: number
          created_at: string
          created_by: string | null
          id: string
          payment_date: string
          payment_method: string | null
          receipt_url: string | null
          student_fee_id: string
          transaction_id: string | null
        }
        Insert: {
          amount: number
          created_at?: string
          created_by?: string | null
          id?: string
          payment_date?: string
          payment_method?: string | null
          receipt_url?: string | null
          student_fee_id: string
          transaction_id?: string | null
        }
        Update: {
          amount?: number
          created_at?: string
          created_by?: string | null
          id?: string
          payment_date?: string
          payment_method?: string | null
          receipt_url?: string | null
          student_fee_id?: string
          transaction_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fee_payments_student_fee_id_fkey"
            columns: ["student_fee_id"]
            isOneToOne: false
            referencedRelation: "student_fees"
            referencedColumns: ["id"]
          },
        ]
      }
      fee_structures: {
        Row: {
          academic_year: string
          amount: number
          created_at: string
          department_id: string
          due_date: string | null
          fee_type: Database["public"]["Enums"]["fee_type"]
          id: string
          program: string
          semester: string
          updated_at: string
        }
        Insert: {
          academic_year: string
          amount: number
          created_at?: string
          department_id: string
          due_date?: string | null
          fee_type: Database["public"]["Enums"]["fee_type"]
          id?: string
          program: string
          semester: string
          updated_at?: string
        }
        Update: {
          academic_year?: string
          amount?: number
          created_at?: string
          department_id?: string
          due_date?: string | null
          fee_type?: Database["public"]["Enums"]["fee_type"]
          id?: string
          program?: string
          semester?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fee_structures_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      grades: {
        Row: {
          class_id: string
          comments: string | null
          created_at: string
          created_by: string
          exam_date: string | null
          exam_type: string
          grade: string | null
          id: string
          marks_obtained: number
          max_marks: number
          student_id: string
          updated_at: string
        }
        Insert: {
          class_id: string
          comments?: string | null
          created_at?: string
          created_by: string
          exam_date?: string | null
          exam_type: string
          grade?: string | null
          id?: string
          marks_obtained: number
          max_marks: number
          student_id: string
          updated_at?: string
        }
        Update: {
          class_id?: string
          comments?: string | null
          created_at?: string
          created_by?: string
          exam_date?: string | null
          exam_type?: string
          grade?: string | null
          id?: string
          marks_obtained?: number
          max_marks?: number
          student_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "grades_class_id_fkey"
            columns: ["class_id"]
            isOneToOne: false
            referencedRelation: "classes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "grades_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      job_applications: {
        Row: {
          applicant_name: string
          cover_letter: string | null
          created_at: string
          email: string
          id: string
          interview_date: string | null
          job_id: string
          notes: string | null
          phone: string | null
          resume_url: string | null
          score: number | null
          status: Database["public"]["Enums"]["application_status"]
          updated_at: string
        }
        Insert: {
          applicant_name: string
          cover_letter?: string | null
          created_at?: string
          email: string
          id?: string
          interview_date?: string | null
          job_id: string
          notes?: string | null
          phone?: string | null
          resume_url?: string | null
          score?: number | null
          status?: Database["public"]["Enums"]["application_status"]
          updated_at?: string
        }
        Update: {
          applicant_name?: string
          cover_letter?: string | null
          created_at?: string
          email?: string
          id?: string
          interview_date?: string | null
          job_id?: string
          notes?: string | null
          phone?: string | null
          resume_url?: string | null
          score?: number | null
          status?: Database["public"]["Enums"]["application_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "job_applications_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "recruitment_jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      leave_requests: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          comments: string | null
          created_at: string
          days_requested: number
          end_date: string
          id: string
          leave_type: Database["public"]["Enums"]["leave_type"]
          reason: string
          start_date: string
          status: Database["public"]["Enums"]["leave_status"]
          updated_at: string
          user_id: string
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          comments?: string | null
          created_at?: string
          days_requested: number
          end_date: string
          id?: string
          leave_type: Database["public"]["Enums"]["leave_type"]
          reason: string
          start_date: string
          status?: Database["public"]["Enums"]["leave_status"]
          updated_at?: string
          user_id: string
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          comments?: string | null
          created_at?: string
          days_requested?: number
          end_date?: string
          id?: string
          leave_type?: Database["public"]["Enums"]["leave_type"]
          reason?: string
          start_date?: string
          status?: Database["public"]["Enums"]["leave_status"]
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          action_url: string | null
          created_at: string
          id: string
          is_read: boolean
          message: string
          title: string
          type: string
          user_id: string
        }
        Insert: {
          action_url?: string | null
          created_at?: string
          id?: string
          is_read?: boolean
          message: string
          title: string
          type: string
          user_id: string
        }
        Update: {
          action_url?: string | null
          created_at?: string
          id?: string
          is_read?: boolean
          message?: string
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      positions: {
        Row: {
          created_at: string
          department_id: string
          employment_type: Database["public"]["Enums"]["employment_type"]
          id: string
          is_active: boolean
          requirements: string[] | null
          responsibilities: string[] | null
          salary_max: number | null
          salary_min: number | null
          title: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          department_id: string
          employment_type: Database["public"]["Enums"]["employment_type"]
          id?: string
          is_active?: boolean
          requirements?: string[] | null
          responsibilities?: string[] | null
          salary_max?: number | null
          salary_min?: number | null
          title: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          department_id?: string
          employment_type?: Database["public"]["Enums"]["employment_type"]
          id?: string
          is_active?: boolean
          requirements?: string[] | null
          responsibilities?: string[] | null
          salary_max?: number | null
          salary_min?: number | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "positions_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          address: Json | null
          avatar_url: string | null
          created_at: string
          date_of_birth: string | null
          email: string
          emergency_contact: Json | null
          employee_id: string | null
          first_name: string
          gender: string | null
          id: string
          last_name: string
          phone: string | null
          student_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          address?: Json | null
          avatar_url?: string | null
          created_at?: string
          date_of_birth?: string | null
          email: string
          emergency_contact?: Json | null
          employee_id?: string | null
          first_name: string
          gender?: string | null
          id?: string
          last_name: string
          phone?: string | null
          student_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          address?: Json | null
          avatar_url?: string | null
          created_at?: string
          date_of_birth?: string | null
          email?: string
          emergency_contact?: Json | null
          employee_id?: string | null
          first_name?: string
          gender?: string | null
          id?: string
          last_name?: string
          phone?: string | null
          student_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      recruitment_jobs: {
        Row: {
          application_deadline: string | null
          created_at: string
          description: string
          id: string
          is_active: boolean
          position_id: string
          posted_by: string
          posted_date: string
          requirements: string[] | null
          title: string
          updated_at: string
        }
        Insert: {
          application_deadline?: string | null
          created_at?: string
          description: string
          id?: string
          is_active?: boolean
          position_id: string
          posted_by: string
          posted_date?: string
          requirements?: string[] | null
          title: string
          updated_at?: string
        }
        Update: {
          application_deadline?: string | null
          created_at?: string
          description?: string
          id?: string
          is_active?: boolean
          position_id?: string
          posted_by?: string
          posted_date?: string
          requirements?: string[] | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "recruitment_jobs_position_id_fkey"
            columns: ["position_id"]
            isOneToOne: false
            referencedRelation: "positions"
            referencedColumns: ["id"]
          },
        ]
      }
      research_grants: {
        Row: {
          amount_requested: number
          amount_sanctioned: number | null
          co_investigators: string[] | null
          created_at: string
          deliverables: string[] | null
          description: string | null
          end_date: string | null
          funding_agency: string
          id: string
          objectives: string[] | null
          principal_investigator: string
          start_date: string | null
          status: Database["public"]["Enums"]["grant_status"]
          title: string
          updated_at: string
        }
        Insert: {
          amount_requested: number
          amount_sanctioned?: number | null
          co_investigators?: string[] | null
          created_at?: string
          deliverables?: string[] | null
          description?: string | null
          end_date?: string | null
          funding_agency: string
          id?: string
          objectives?: string[] | null
          principal_investigator: string
          start_date?: string | null
          status?: Database["public"]["Enums"]["grant_status"]
          title: string
          updated_at?: string
        }
        Update: {
          amount_requested?: number
          amount_sanctioned?: number | null
          co_investigators?: string[] | null
          created_at?: string
          deliverables?: string[] | null
          description?: string | null
          end_date?: string | null
          funding_agency?: string
          id?: string
          objectives?: string[] | null
          principal_investigator?: string
          start_date?: string | null
          status?: Database["public"]["Enums"]["grant_status"]
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      student_enrollments: {
        Row: {
          class_id: string
          created_at: string
          enrollment_date: string
          id: string
          is_active: boolean
          student_id: string
        }
        Insert: {
          class_id: string
          created_at?: string
          enrollment_date?: string
          id?: string
          is_active?: boolean
          student_id: string
        }
        Update: {
          class_id?: string
          created_at?: string
          enrollment_date?: string
          id?: string
          is_active?: boolean
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "student_enrollments_class_id_fkey"
            columns: ["class_id"]
            isOneToOne: false
            referencedRelation: "classes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_enrollments_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      student_fees: {
        Row: {
          amount_due: number
          amount_paid: number
          created_at: string
          due_date: string
          fee_structure_id: string
          id: string
          status: Database["public"]["Enums"]["payment_status"]
          student_id: string
          updated_at: string
        }
        Insert: {
          amount_due: number
          amount_paid?: number
          created_at?: string
          due_date: string
          fee_structure_id: string
          id?: string
          status?: Database["public"]["Enums"]["payment_status"]
          student_id: string
          updated_at?: string
        }
        Update: {
          amount_due?: number
          amount_paid?: number
          created_at?: string
          due_date?: string
          fee_structure_id?: string
          id?: string
          status?: Database["public"]["Enums"]["payment_status"]
          student_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "student_fees_fee_structure_id_fkey"
            columns: ["fee_structure_id"]
            isOneToOne: false
            referencedRelation: "fee_structures"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_fees_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      students: {
        Row: {
          academic_year: string
          admission_date: string
          admission_number: string | null
          cgpa: number | null
          created_at: string
          department_id: string
          graduation_date: string | null
          id: string
          is_active: boolean
          program: string
          semester: string | null
          student_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          academic_year: string
          admission_date: string
          admission_number?: string | null
          cgpa?: number | null
          created_at?: string
          department_id: string
          graduation_date?: string | null
          id?: string
          is_active?: boolean
          program: string
          semester?: string | null
          student_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          academic_year?: string
          admission_date?: string
          admission_number?: string | null
          cgpa?: number | null
          created_at?: string
          department_id?: string
          graduation_date?: string | null
          id?: string
          is_active?: boolean
          program?: string
          semester?: string | null
          student_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "students_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      timetables: {
        Row: {
          class_id: string
          created_at: string
          day_of_week: number
          end_time: string
          id: string
          room: string | null
          start_time: string
          updated_at: string
        }
        Insert: {
          class_id: string
          created_at?: string
          day_of_week: number
          end_time: string
          id?: string
          room?: string | null
          start_time: string
          updated_at?: string
        }
        Update: {
          class_id?: string
          created_at?: string
          day_of_week?: number
          end_time?: string
          id?: string
          room?: string | null
          start_time?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "timetables_class_id_fkey"
            columns: ["class_id"]
            isOneToOne: false
            referencedRelation: "classes"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_user_role: {
        Args: { user_uuid: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      has_role: {
        Args: {
          role_name: Database["public"]["Enums"]["app_role"]
          user_uuid: string
        }
        Returns: boolean
      }
      is_admin: {
        Args: { user_uuid: string }
        Returns: boolean
      }
      is_faculty: {
        Args: { user_uuid: string }
        Returns: boolean
      }
      is_hr_staff: {
        Args: { user_uuid: string }
        Returns: boolean
      }
      is_student: {
        Args: { user_uuid: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "hr_staff" | "faculty" | "student" | "adjunct"
      application_status:
        | "submitted"
        | "screening"
        | "interview"
        | "selected"
        | "rejected"
      attendance_status: "present" | "absent" | "late" | "excused"
      employment_type: "full_time" | "part_time" | "contract" | "adjunct"
      fee_type: "tuition" | "hostel" | "library" | "lab" | "exam" | "other"
      grant_status:
        | "draft"
        | "submitted"
        | "under_review"
        | "approved"
        | "rejected"
        | "active"
        | "completed"
      leave_status: "pending" | "approved" | "rejected"
      leave_type:
        | "sick"
        | "casual"
        | "sabbatical"
        | "research"
        | "medical"
        | "maternity"
        | "paternity"
      payment_status: "pending" | "paid" | "overdue" | "partial"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "hr_staff", "faculty", "student", "adjunct"],
      application_status: [
        "submitted",
        "screening",
        "interview",
        "selected",
        "rejected",
      ],
      attendance_status: ["present", "absent", "late", "excused"],
      employment_type: ["full_time", "part_time", "contract", "adjunct"],
      fee_type: ["tuition", "hostel", "library", "lab", "exam", "other"],
      grant_status: [
        "draft",
        "submitted",
        "under_review",
        "approved",
        "rejected",
        "active",
        "completed",
      ],
      leave_status: ["pending", "approved", "rejected"],
      leave_type: [
        "sick",
        "casual",
        "sabbatical",
        "research",
        "medical",
        "maternity",
        "paternity",
      ],
      payment_status: ["pending", "paid", "overdue", "partial"],
    },
  },
} as const
