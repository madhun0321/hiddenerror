
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Users, 
  Calendar, 
  FileText, 
  TrendingUp, 
  Search, 
  Bell, 
  Settings,
  UserPlus,
  Clock,
  DollarSign,
  BookOpen,
  Award,
  BarChart3,
  Shield,
  Smartphone
} from "lucide-react";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import Dashboard from "@/components/Dashboard";
import EmployeeDirectory from "@/components/EmployeeDirectory";
import RecruitmentHub from "@/components/RecruitmentHub";
import LeaveManagement from "@/components/LeaveManagement";

const Index = () => {
  const [activeModule, setActiveModule] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const renderActiveModule = () => {
    switch (activeModule) {
      case "dashboard":
        return <Dashboard />;
      case "employees":
        return <EmployeeDirectory />;
      case "recruitment":
        return <RecruitmentHub />;
      case "leave":
        return <LeaveManagement />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header setSidebarOpen={setSidebarOpen} sidebarOpen={sidebarOpen} />
      
      <div className="flex">
        <Sidebar 
          activeModule={activeModule} 
          setActiveModule={setActiveModule}
          isOpen={sidebarOpen}
        />
        
        <main className={`flex-1 transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-16'}`}>
          <div className="p-6">
            {renderActiveModule()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Index;
