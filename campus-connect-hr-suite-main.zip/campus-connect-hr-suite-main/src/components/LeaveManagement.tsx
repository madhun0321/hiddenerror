
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, Clock, CheckCircle, XCircle, AlertCircle, TrendingUp } from "lucide-react";

const LeaveManagement = () => {
  const [activeTab, setActiveTab] = useState("pending");

  const leaveRequests = {
    pending: [
      {
        id: "LR001",
        employee: "Dr. Rajesh Kumar",
        department: "Computer Science",
        type: "Annual Leave",
        startDate: "2024-12-15",
        endDate: "2024-12-20",
        days: 6,
        reason: "Family vacation",
        submitted: "2024-12-01",
        avatar: "/placeholder.svg"
      },
      {
        id: "LR002",
        employee: "Dr. Priya Sharma",
        department: "Mathematics",
        type: "Sick Leave",
        startDate: "2024-12-10",
        endDate: "2024-12-12",
        days: 3,
        reason: "Medical treatment",
        submitted: "2024-12-08",
        avatar: "/placeholder.svg"
      }
    ],
    approved: [
      {
        id: "LR003",
        employee: "Prof. Michael Chen",
        department: "Physics",
        type: "Conference Leave",
        startDate: "2024-11-25",
        endDate: "2024-11-27",
        days: 3,
        reason: "International Physics Conference",
        approved: "2024-11-20",
        avatar: "/placeholder.svg"
      }
    ],
    rejected: [
      {
        id: "LR004",
        employee: "Dr. Anita Reddy",
        department: "Chemistry",
        type: "Annual Leave",
        startDate: "2024-12-20",
        endDate: "2024-12-25",
        days: 6,
        reason: "Personal work",
        rejected: "2024-11-30",
        rejectionReason: "Exam period - essential staff required",
        avatar: "/placeholder.svg"
      }
    ]
  };

  const metrics = [
    { label: "Pending Requests", value: "45", change: "+8", icon: Clock, color: "orange" },
    { label: "Approved Today", value: "12", change: "+3", icon: CheckCircle, color: "green" },
    { label: "Average Days", value: "4.2", change: "-0.5", icon: Calendar, color: "blue" },
    { label: "Leave Utilization", value: "67%", change: "+5%", icon: TrendingUp, color: "purple" }
  ];

  const leaveTypes = [
    { type: "Annual Leave", used: 15, total: 24, color: "blue" },
    { type: "Sick Leave", used: 3, total: 12, color: "red" },
    { type: "Conference Leave", used: 5, total: 10, color: "green" },
    { type: "Maternity Leave", used: 2, total: 180, color: "purple" }
  ];

  const renderLeaveRequest = (request: any, status: string) => (
    <div key={request.id} className="border rounded-lg p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Avatar>
            <AvatarImage src={request.avatar} alt={request.employee} />
            <AvatarFallback>
              {request.employee.split(' ').map((n: string) => n[0]).join('')}
            </AvatarFallback>
          </Avatar>
          <div>
            <p className="font-medium">{request.employee}</p>
            <p className="text-sm text-gray-600">{request.department}</p>
          </div>
        </div>
        <Badge variant={
          status === 'pending' ? 'secondary' :
          status === 'approved' ? 'default' : 'destructive'
        }>
          {request.type}
        </Badge>
      </div>

      <div className="grid grid-cols-2 gap-4 text-sm">
        <div>
          <p className="text-gray-600">Duration</p>
          <p className="font-medium">{request.startDate} to {request.endDate}</p>
          <p className="text-gray-600">{request.days} days</p>
        </div>
        <div>
          <p className="text-gray-600">Reason</p>
          <p className="font-medium">{request.reason}</p>
        </div>
      </div>

      {request.rejectionReason && (
        <div className="bg-red-50 border border-red-200 rounded p-3">
          <p className="text-sm text-red-800">
            <strong>Rejection Reason:</strong> {request.rejectionReason}
          </p>
        </div>
      )}

      {status === 'pending' && (
        <div className="flex space-x-2">
          <Button size="sm" variant="default">
            <CheckCircle className="h-4 w-4 mr-1" />
            Approve
          </Button>
          <Button size="sm" variant="outline">
            <XCircle className="h-4 w-4 mr-1" />
            Reject
          </Button>
          <Button size="sm" variant="ghost">
            View Details
          </Button>
        </div>
      )}

      {status !== 'pending' && (
        <div className="flex justify-between items-center">
          <p className="text-xs text-gray-500">
            {status === 'approved' ? `Approved on ${request.approved}` : `Rejected on ${request.rejected}`}
          </p>
          <Button size="sm" variant="ghost">
            View Details
          </Button>
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Leave & Attendance</h1>
          <p className="text-gray-600 mt-1">Manage leave requests and attendance tracking</p>
        </div>
        <div className="flex space-x-3">
          <Button variant="outline">
            <Calendar className="h-4 w-4 mr-2" />
            Calendar View
          </Button>
          <Button>
            <Clock className="h-4 w-4 mr-2" />
            New Request
          </Button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{metric.label}</p>
                    <p className="text-2xl font-bold">{metric.value}</p>
                    <p className="text-xs text-green-600 flex items-center mt-1">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      {metric.change}
                    </p>
                  </div>
                  <div className={`p-3 bg-${metric.color}-100 rounded-lg`}>
                    <Icon className={`h-5 w-5 text-${metric.color}-600`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Leave Requests */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Leave Requests</CardTitle>
              <CardDescription>Review and manage employee leave requests</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="pending" className="flex items-center space-x-2">
                    <AlertCircle className="h-4 w-4" />
                    <span>Pending ({leaveRequests.pending.length})</span>
                  </TabsTrigger>
                  <TabsTrigger value="approved" className="flex items-center space-x-2">
                    <CheckCircle className="h-4 w-4" />
                    <span>Approved ({leaveRequests.approved.length})</span>
                  </TabsTrigger>
                  <TabsTrigger value="rejected" className="flex items-center space-x-2">
                    <XCircle className="h-4 w-4" />
                    <span>Rejected ({leaveRequests.rejected.length})</span>
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="pending" className="space-y-4 mt-4">
                  {leaveRequests.pending.map(request => renderLeaveRequest(request, 'pending'))}
                </TabsContent>

                <TabsContent value="approved" className="space-y-4 mt-4">
                  {leaveRequests.approved.map(request => renderLeaveRequest(request, 'approved'))}
                </TabsContent>

                <TabsContent value="rejected" className="space-y-4 mt-4">
                  {leaveRequests.rejected.map(request => renderLeaveRequest(request, 'rejected'))}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        {/* Leave Balance Overview */}
        <Card>
          <CardHeader>
            <CardTitle>Leave Balance Overview</CardTitle>
            <CardDescription>Current leave utilization across types</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {leaveTypes.map((leave, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium">{leave.type}</span>
                    <span className="text-gray-600">{leave.used}/{leave.total} days</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className={`bg-${leave.color}-600 h-2 rounded-full`}
                      style={{ width: `${(leave.used / leave.total) * 100}%` }}
                    ></div>
                  </div>
                  <p className="text-xs text-gray-500">
                    {leave.total - leave.used} days remaining
                  </p>
                </div>
              ))}
            </div>

            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">Quick Actions</h4>
              <div className="space-y-2">
                <Button variant="outline" size="sm" className="w-full justify-start">
                  <Calendar className="h-4 w-4 mr-2" />
                  View Leave Calendar
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start">
                  <Clock className="h-4 w-4 mr-2" />
                  Attendance Reports
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start">
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Leave Analytics
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default LeaveManagement;
