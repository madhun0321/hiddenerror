
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Search, Filter, Download, Mail, Phone, MapPin, UserPlus } from "lucide-react";

const EmployeeDirectory = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("all");
  const [roleFilter, setRoleFilter] = useState("all");

  const employees = [
    {
      id: "EMP001",
      name: "Dr. Rajesh Kumar",
      email: "rajesh.kumar@college.edu",
      phone: "+91 98765 43210",
      department: "Computer Science",
      role: "Professor",
      location: "Block A, Room 201",
      status: "active",
      joinDate: "2018-08-15",
      avatar: "/placeholder.svg"
    },
    {
      id: "EMP002",
      name: "Dr. Priya Sharma",
      email: "priya.sharma@college.edu",
      phone: "+91 98765 43211",
      department: "Mathematics",
      role: "Associate Professor",
      location: "Block B, Room 105",
      status: "active",
      joinDate: "2019-01-10",
      avatar: "/placeholder.svg"
    },
    {
      id: "EMP003",
      name: "Mr. Amit Patel",
      email: "amit.patel@college.edu",
      phone: "+91 98765 43212",
      department: "Administration",
      role: "HR Manager",
      location: "Admin Block, Room 301",
      status: "active",
      joinDate: "2020-03-22",
      avatar: "/placeholder.svg"
    },
    {
      id: "EMP004",
      name: "Dr. Sarah Johnson",
      email: "sarah.johnson@college.edu",
      phone: "+91 98765 43213",
      department: "Administration",
      role: "HR Director",
      location: "Admin Block, Room 401",
      status: "active",
      joinDate: "2017-06-01",
      avatar: "/placeholder.svg"
    },
    {
      id: "EMP005",
      name: "Prof. Michael Chen",
      email: "michael.chen@college.edu",
      phone: "+91 98765 43214",
      department: "Physics",
      role: "Professor",
      location: "Block C, Room 301",
      status: "active",
      joinDate: "2016-09-12",
      avatar: "/placeholder.svg"
    },
    {
      id: "EMP006",
      name: "Dr. Anita Reddy",
      email: "anita.reddy@college.edu",
      phone: "+91 98765 43215",
      department: "Chemistry",
      role: "Assistant Professor",
      location: "Block D, Room 102",
      status: "active",
      joinDate: "2021-07-01",
      avatar: "/placeholder.svg"
    }
  ];

  const departments = [...new Set(employees.map(emp => emp.department))];
  const roles = [...new Set(employees.map(emp => emp.role))];

  const filteredEmployees = employees.filter(employee => {
    const matchesSearch = employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         employee.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         employee.department.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDepartment = departmentFilter === "all" || employee.department === departmentFilter;
    const matchesRole = roleFilter === "all" || employee.role === roleFilter;
    
    return matchesSearch && matchesDepartment && matchesRole;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Employee Directory</h1>
          <p className="text-gray-600 mt-1">Manage and view all employees across the campus</p>
        </div>
        <div className="flex space-x-3">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button>
            <UserPlus className="h-4 w-4 mr-2" />
            Add Employee
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Search & Filter</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search employees..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Department" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Departments</SelectItem>
                {departments.map(dept => (
                  <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                {roles.map(role => (
                  <SelectItem key={role} value={role}>{role}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button variant="outline" className="w-full">
              <Filter className="h-4 w-4 mr-2" />
              Advanced Filters
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results Summary */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-gray-600">
          Showing {filteredEmployees.length} of {employees.length} employees
        </p>
        <div className="flex space-x-2">
          <Badge variant="secondary">{employees.filter(e => e.status === 'active').length} Active</Badge>
          <Badge variant="outline">{departments.length} Departments</Badge>
        </div>
      </div>

      {/* Employee Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredEmployees.map((employee) => (
          <Card key={employee.id} className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="pb-4">
              <div className="flex items-center space-x-4">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={employee.avatar} alt={employee.name} />
                  <AvatarFallback>
                    {employee.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg">{employee.name}</h3>
                  <p className="text-sm text-gray-600">{employee.role}</p>
                  <Badge variant="secondary" className="mt-1">
                    {employee.department}
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-2">
                <div className="flex items-center text-sm text-gray-600">
                  <Mail className="h-4 w-4 mr-2" />
                  {employee.email}
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Phone className="h-4 w-4 mr-2" />
                  {employee.phone}
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <MapPin className="h-4 w-4 mr-2" />
                  {employee.location}
                </div>
              </div>
              
              <div className="flex space-x-2 mt-4">
                <Button variant="outline" size="sm" className="flex-1">
                  View Profile
                </Button>
                <Button variant="outline" size="sm">
                  <Mail className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm">
                  <Phone className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Load More */}
      {filteredEmployees.length >= 6 && (
        <div className="text-center">
          <Button variant="outline" size="lg">
            Load More Employees
          </Button>
        </div>
      )}
    </div>
  );
};

export default EmployeeDirectory;
