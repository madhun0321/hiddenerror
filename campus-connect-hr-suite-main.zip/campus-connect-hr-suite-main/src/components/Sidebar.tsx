
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import {
  Users,
  UserPlus,
  Calendar,
  Clock,
  DollarSign,
  FileText,
  BookOpen,
  Award,
  TrendingUp,
  BarChart3,
  Shield,
  Smartphone,
  Settings,
  HelpCircle,
  LayoutDashboard
} from "lucide-react";

interface SidebarProps {
  activeModule: string;
  setActiveModule: (module: string) => void;
  isOpen: boolean;
}

const Sidebar = ({ activeModule, setActiveModule, isOpen }: SidebarProps) => {
  const menuSections = [
    {
      title: "Core Modules",
      items: [
        { id: "dashboard", label: "Dashboard", icon: LayoutDashboard, badge: null },
        { id: "employees", label: "Employee Directory", icon: Users, badge: "1,247" },
        { id: "recruitment", label: "Recruitment", icon: UserPlus, badge: "23" },
        { id: "leave", label: "Leave & Attendance", icon: Clock, badge: "45" },
        { id: "payroll", label: "Payroll & Benefits", icon: DollarSign, badge: null },
        { id: "documents", label: "Document Manager", icon: FileText, badge: "12" },
      ]
    },
    {
      title: "College Specific",
      items: [
        { id: "faculty", label: "Faculty Workload", icon: Calendar, badge: null },
        { id: "research", label: "Research Grants", icon: BookOpen, badge: "8" },
        { id: "events", label: "Guest Lectures", icon: Award, badge: "3" },
      ]
    },
    {
      title: "Analytics & Reports",
      items: [
        { id: "performance", label: "Performance", icon: TrendingUp, badge: null },
        { id: "analytics", label: "Analytics Hub", icon: BarChart3, badge: null },
        { id: "compliance", label: "Compliance", icon: Shield, badge: "2" },
      ]
    },
    {
      title: "Tools",
      items: [
        { id: "mobile", label: "Mobile App", icon: Smartphone, badge: null },
        { id: "settings", label: "Settings", icon: Settings, badge: null },
        { id: "help", label: "Help & Support", icon: HelpCircle, badge: null },
      ]
    }
  ];

  return (
    <aside className={cn(
      "fixed left-0 top-16 h-[calc(100vh-4rem)] bg-white border-r border-gray-200 transition-all duration-300 z-40",
      isOpen ? "w-64" : "w-16"
    )}>
      <div className="flex flex-col h-full">
        <div className="flex-1 overflow-y-auto py-4">
          {menuSections.map((section, sectionIndex) => (
            <div key={section.title} className={cn("mb-6", sectionIndex > 0 && "border-t border-gray-100 pt-4")}>
              {isOpen && (
                <h3 className="px-4 mb-2 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                  {section.title}
                </h3>
              )}
              <nav className="space-y-1 px-2">
                {section.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeModule === item.id;
                  
                  return (
                    <Button
                      key={item.id}
                      variant={isActive ? "secondary" : "ghost"}
                      className={cn(
                        "w-full justify-start h-10 px-3",
                        !isOpen && "justify-center px-0",
                        isActive && "bg-blue-50 text-blue-700 border-blue-200"
                      )}
                      onClick={() => setActiveModule(item.id)}
                    >
                      <Icon className={cn("h-5 w-5", isOpen && "mr-3")} />
                      {isOpen && (
                        <>
                          <span className="flex-1 text-left">{item.label}</span>
                          {item.badge && (
                            <Badge variant="secondary" className="ml-auto bg-gray-100 text-gray-600 text-xs">
                              {item.badge}
                            </Badge>
                          )}
                        </>
                      )}
                    </Button>
                  );
                })}
              </nav>
            </div>
          ))}
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
