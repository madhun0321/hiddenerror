
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Plus, 
  Users, 
  Calendar, 
  FileText, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  TrendingUp
} from "lucide-react";

const RecruitmentHub = () => {
  const activeJobs = [
    {
      id: "JOB001",
      title: "Associate Professor - Computer Science",
      department: "Computer Science",
      type: "Full-time",
      applications: 47,
      status: "active",
      deadline: "2024-12-20",
      posted: "2024-11-15"
    },
    {
      id: "JOB002", 
      title: "Research Assistant - AI Lab",
      department: "Computer Science",
      type: "Part-time",
      applications: 23,
      status: "active",
      deadline: "2024-12-15",
      posted: "2024-11-20"
    },
    {
      id: "JOB003",
      title: "Administrative Officer",
      department: "Administration",
      type: "Full-time",
      applications: 89,
      status: "review",
      deadline: "2024-12-10",
      posted: "2024-11-01"
    }
  ];

  const recentApplications = [
    {
      id: "APP001",
      candidate: "Dr. Amit Singh",
      position: "Associate Professor - Computer Science",
      stage: "Interview Scheduled",
      score: 85,
      avatar: "/placeholder.svg"
    },
    {
      id: "APP002",
      candidate: "Ms. Neha Gupta",
      position: "Research Assistant - AI Lab",
      stage: "Technical Review",
      score: 78,
      avatar: "/placeholder.svg"
    },
    {
      id: "APP003",
      candidate: "Mr. Rohit Sharma",
      position: "Administrative Officer",
      stage: "HR Screening",
      score: 92,
      avatar: "/placeholder.svg"
    }
  ];

  const metrics = [
    { label: "Open Positions", value: "23", change: "+3", icon: Users },
    { label: "Total Applications", value: "159", change: "+12", icon: FileText },
    { label: "Interviews Scheduled", value: "8", change: "+2", icon: Calendar },
    { label: "Avg. Time to Hire", value: "18 days", change: "-2", icon: Clock }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Recruitment Hub</h1>
          <p className="text-gray-600 mt-1">Manage job postings, applications, and hiring pipeline</p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Post New Job
        </Button>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{metric.label}</p>
                    <p className="text-2xl font-bold">{metric.value}</p>
                    <p className="text-xs text-green-600 flex items-center mt-1">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      {metric.change} this week
                    </p>
                  </div>
                  <div className="p-3 bg-blue-100 rounded-lg">
                    <Icon className="h-5 w-5 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Active Job Postings */}
        <Card>
          <CardHeader>
            <CardTitle>Active Job Postings</CardTitle>
            <CardDescription>Currently open positions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {activeJobs.map((job) => (
                <div key={job.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium">{job.title}</h3>
                      <p className="text-sm text-gray-600">{job.department}</p>
                    </div>
                    <Badge variant={job.status === 'active' ? 'default' : 'secondary'}>
                      {job.status}
                    </Badge>
                  </div>
                  
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>{job.type}</span>
                    <span>Deadline: {job.deadline}</span>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <Users className="h-4 w-4" />
                      <span className="text-sm">{job.applications} applications</span>
                    </div>
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Applications */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Applications</CardTitle>
            <CardDescription>Latest candidate submissions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentApplications.map((app) => (
                <div key={app.id} className="flex items-center space-x-4 p-3 border rounded-lg">
                  <Avatar>
                    <AvatarImage src={app.avatar} alt={app.candidate} />
                    <AvatarFallback>
                      {app.candidate.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <p className="font-medium">{app.candidate}</p>
                    <p className="text-sm text-gray-600">{app.position}</p>
                    <div className="flex items-center space-x-2 mt-1">
                      <Badge variant="outline" className="text-xs">
                        {app.stage}
                      </Badge>
                      <span className="text-xs text-gray-500">Score: {app.score}%</span>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">
                      Review
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            <Button variant="outline" className="w-full mt-4">
              View All Applications
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Hiring Pipeline */}
      <Card>
        <CardHeader>
          <CardTitle>Hiring Pipeline</CardTitle>
          <CardDescription>Current recruitment stages and progress</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
              <p className="text-sm font-medium">Applications</p>
              <p className="text-2xl font-bold text-blue-600">159</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Clock className="h-6 w-6 text-orange-600" />
              </div>
              <p className="text-sm font-medium">Screening</p>
              <p className="text-2xl font-bold text-orange-600">34</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <Calendar className="h-6 w-6 text-purple-600" />
              </div>
              <p className="text-sm font-medium">Interviews</p>
              <p className="text-2xl font-bold text-purple-600">15</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <AlertCircle className="h-6 w-6 text-yellow-600" />
              </div>
              <p className="text-sm font-medium">Final Review</p>
              <p className="text-2xl font-bold text-yellow-600">6</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <p className="text-sm font-medium">Offers</p>
              <p className="text-2xl font-bold text-green-600">3</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default RecruitmentHub;
