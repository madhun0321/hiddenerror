
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import {
  Users,
  UserPlus,
  Clock,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Calendar,
  DollarSign,
  Award
} from "lucide-react";

const Dashboard = () => {
  const metrics = [
    {
      title: "Total Employees",
      value: "1,247",
      change: "+12%",
      trend: "up",
      icon: Users,
      color: "blue"
    },
    {
      title: "Active Recruitments",
      value: "23",
      change: "+5 this week",
      trend: "up",
      icon: UserPlus,
      color: "green"
    },
    {
      title: "Leave Requests",
      value: "45",
      change: "8 pending",
      trend: "neutral",
      icon: Clock,
      color: "orange"
    },
    {
      title: "Monthly Payroll",
      value: "₹2.4Cr",
      change: "+3.2%",
      trend: "up",
      icon: DollarSign,
      color: "purple"
    }
  ];

  const recentActivities = [
    {
      type: "recruitment",
      title: "New Application: Computer Science Professor",
      time: "2 hours ago",
      status: "review"
    },
    {
      type: "leave",
      title: "Leave approved for Dr. Rajesh Kumar",
      time: "4 hours ago",
      status: "approved"
    },
    {
      type: "payroll",
      title: "Monthly payroll processed successfully",
      time: "1 day ago",
      status: "completed"
    },
    {
      type: "compliance",
      title: "Annual compliance report due in 7 days",
      time: "2 days ago",
      status: "warning"
    }
  ];

  const upcomingEvents = [
    {
      title: "Faculty Performance Reviews",
      date: "Dec 15-20, 2024",
      type: "Performance"
    },
    {
      title: "New Employee Orientation",
      date: "Dec 12, 2024",
      type: "Training"
    },
    {
      title: "Research Grant Deadline",
      date: "Dec 18, 2024",
      type: "Research"
    }
  ];

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-lg p-6 text-white">
        <h1 className="text-2xl font-bold mb-2">Welcome back, Dr. Sarah Johnson</h1>
        <p className="text-blue-100">Here's what's happening at your campus today.</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <Card key={index} className="relative overflow-hidden">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">
                  {metric.title}
                </CardTitle>
                <div className={`p-2 rounded-lg bg-${metric.color}-100`}>
                  <Icon className={`h-4 w-4 text-${metric.color}-600`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{metric.value}</div>
                <p className="text-xs text-gray-600 flex items-center mt-1">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  {metric.change}
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activities */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Recent Activities</CardTitle>
            <CardDescription>Latest updates across all modules</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivities.map((activity, index) => (
                <div key={index} className="flex items-center space-x-4 p-3 rounded-lg bg-gray-50">
                  <div className={`p-2 rounded-lg ${
                    activity.status === 'approved' ? 'bg-green-100' :
                    activity.status === 'warning' ? 'bg-orange-100' :
                    activity.status === 'completed' ? 'bg-blue-100' : 'bg-gray-100'
                  }`}>
                    {activity.status === 'approved' && <CheckCircle className="h-4 w-4 text-green-600" />}
                    {activity.status === 'warning' && <AlertTriangle className="h-4 w-4 text-orange-600" />}
                    {activity.status === 'completed' && <CheckCircle className="h-4 w-4 text-blue-600" />}
                    {activity.status === 'review' && <Clock className="h-4 w-4 text-gray-600" />}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{activity.title}</p>
                    <p className="text-xs text-gray-500">{activity.time}</p>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {activity.type}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Events */}
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Events</CardTitle>
            <CardDescription>Important dates and deadlines</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingEvents.map((event, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Calendar className="h-4 w-4 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{event.title}</p>
                    <p className="text-xs text-gray-500">{event.date}</p>
                    <Badge variant="secondary" className="mt-1 text-xs">
                      {event.type}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
            <Button variant="outline" className="w-full mt-4">
              View All Events
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Frequently used operations</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
              <UserPlus className="h-5 w-5" />
              <span className="text-sm">Add Employee</span>
            </Button>
            <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
              <Clock className="h-5 w-5" />
              <span className="text-sm">Approve Leave</span>
            </Button>
            <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
              <Award className="h-5 w-5" />
              <span className="text-sm">Post Job</span>
            </Button>
            <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
              <TrendingUp className="h-5 w-5" />
              <span className="text-sm">Generate Report</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;
